<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index" style="overflow-x: hidden;">

    <div class="jubotron">
    	<div class="row">
    		<div class="col-md-12">
    				
    		</div>
    	</div>

    	<div class="row">
    		<div class="col-md-4"></div>
    		<div class="col-md-8 center"><br><br><br><br><br><br>
		  		<img class="img-responsive img-circle" src="images/logo1.jpg" width="400px">
    		</div>
    	</div>	
        

    </div>

    <div class="body-content">

    </div>
</div>
